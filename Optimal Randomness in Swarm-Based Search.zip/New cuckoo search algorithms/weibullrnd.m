function t = weibullrnd(theta, alpha, beta, m, n)
%**************************************************************************************************
% Note: We obtained the MATLAB source code from 
% https://www.mathworks.com/matlabcentral/fileexchange/7309-randraw
% provided by by Sarojkumar, and did some minor revisions for simplicity, the main body was not changed.
%**************************************************************************************************
%  THE WEIBULL DISTRIBUTION
%  ( sometimes: Frechet distribution )
%  cdf = 1 - exp(-((y-theta)/beta).^alpha)
%  pdf = alpha / beta * ((y-theta)/beta).^(alpha-1) .* exp(-((y-theta)/beta).^alpha);
%  Mean = theta + beta*gamma((alpha+1)/alpha);  
%  Variance = beta^2 * ( gamma((alpha+2)/alpha) - gamma((alpha+1)/alpha)^2 );
%       where gamma is the gamma function
% NOTES:
%   If alpha=1 , it is the exponential distribution
%   If beta=1; alpha=2, theta=0; it is the standard Rayleigh distribution (sigma=1)
%
% EXAMPLES:
%  1.   y = randraw('weibull', [-10, 2, 3], [1 1e5]);                      
% END weibull HELP END frechet HELP END wbl HELP
%   theta - location parameter;
%   alpha - shape parameter ( alpha>0 );
%   beta  - scale parameter ( beta>0 );
t = theta + beta * (-log(rand(m,n))).^(1/alpha);
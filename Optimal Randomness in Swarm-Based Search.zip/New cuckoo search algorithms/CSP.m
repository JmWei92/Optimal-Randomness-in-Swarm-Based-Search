clear all; clc;
format long;
format compact;
% CS with Pareto distribution *******%
min_f = [];
aver_f = [];
std_f = [];
saver_f = [];
sstd_f = [];
totalRun_iner_f = [];
problemSet = [1 : 20];
for problemIndex = 1 : length(problemSet)
    func_num = problemSet(problemIndex),
    iner_f = [];
    record = [];
    NP = 30;
    D = 30;
    maxFES = D*10000;
    totalRun = 50;
    lu = boundary(func_num,D);
    pa = 0.25;
    rand('state', sum(100 * clock));
    for time = 1 : totalRun
        outcome_f = [];
        nest = repmat(lu(1,:),NP,1)+rand(NP,D).*(repmat(lu(2,:)-lu(1,:),NP,1));
        fits = benchmark_func(nest,func_num);
        FES = NP;
        [fmin,min_i] = min(fits);
        bestnest = nest(min_i,:);
        iter = 1;
        outcome_f(iter) = fmin;
        new_nest = zeros(NP,D);
        while FES < maxFES
            iter = iter + 1;
            for i=1:NP
                %% generate Pareto random number
                m_p = D;  
                n_p = 1; 
                a_p = 1.5;  
                b_p = 4.5;            
                step = pareto(a_p,b_p,m_p,n_p); 
                stepsize = 0.01*step'.*(nest(i,:)-bestnest);
                new_nest(i,:) = nest(i,:)+stepsize.*randn(1,D);
            end
            if func_num ~= 17
                new_nest = simplebounds(new_nest,lu(1,:),lu(2,:));
            end
            new_fits = benchmark_func(new_nest,func_num);
            FES = FES+NP;
            iBetter = new_fits<fits;
            fits(iBetter) = new_fits(iBetter);
            nest(iBetter,:) = new_nest(iBetter,:);
            paK = rand(size(nest))>pa;
            stepsize = rand*(nest(randperm(NP),:)-nest(randperm(NP),:));
            new_nest = nest+stepsize.*paK;
            if func_num ~= 17
                new_nest = simplebounds(new_nest,lu(1,:),lu(2,:));
            end
            new_fits = benchmark_func(new_nest,func_num);
            FES = FES+NP;
            iBetter = new_fits<fits;
            fits(iBetter) = new_fits(iBetter);
            nest(iBetter,:) = new_nest(iBetter,:);
            [fmin,min_i] = min(fits);
            bestnest = nest(min_i,:);
            outcome_f(iter) = fmin;
        end
        iner_f(time,:) = outcome_f;
        record(time) = outcome_f(end); 
    end
    min_f(func_num) = min(record);  % best
    max_f(func_num) = max(record);  % worst
    med_f(func_num) = median(record);  % median
    aver_f(func_num) = mean(record);  % mean
    std_f(func_num) = std(record); % std
    totalRun_iner_f(func_num,:,:)  = iner_f;
    mean(record)
end
totalRun_CS_Pareto = totalRun_iner_f;
min_f_CS_Pareto = min_f;
max_f_CS_Pareto = max_f;
med_f_CS_Pareto = med_f;
aver_f_CS_Pareto = aver_f;
std_f_CS_Pareto = std_f;

% save('CS_Pareto_30D_2')



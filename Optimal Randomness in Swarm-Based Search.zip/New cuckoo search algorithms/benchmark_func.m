function f=benchmark_func(x,func_num)
% f1-f10 / f11-f20 (F1-F10) 
% 1. Accelerating differential evolution using an adaptive localsearch, IEEE Trans. Evol. Comput. 12 (1) (2008) 107�C125.
% 2. Problem Definitions and Evaluation Criteria for the CEC 2005 Special Session on Real-Parameter Optimization
persistent fhd
    % Basic func 
if func_num==1 fhd=str2func('sphere_func');          %[-100,100] Sphere Function
elseif func_num==2 fhd=str2func('rosenbrock_func');  %[-100,100] Rosenbrock's Function
elseif func_num==3 fhd=str2func('ackley_func');      %[-32,32]   Ackley's Function  
elseif func_num==4 fhd=str2func('griewank_func');    %[-600,600] Griewank's Function
elseif func_num==5 fhd=str2func('rastrigin_func');   %[-5,5]     Rastrigin's Function   
elseif func_num==6 fhd=str2func('schwefel_226');     %[-500,500] Generalized Schwefel's Problem 2.26
elseif func_num==7 fhd=str2func('salomon_func');     %[-100,100] Salomon's Function
elseif func_num==8 fhd=str2func('whitely_func');          %[-100,100] Whitely's Function
elseif func_num==9 fhd=str2func('penalized_func1');  %[-50,50] Generalized Penalized Function 1
elseif func_num==10 fhd=str2func('penalized_func2'); %[-50,50] Generalized Penalized Function 2   
    % CEC2005
elseif func_num==11 fhd=str2func('shifted_sphere_func');           %[-100,100] F1: Shifted Sphere Function
elseif func_num==12 fhd=str2func('shifted_schwefel_func');         %[-100,100] F2: Shifted Schwefel's Problem 1.2
elseif func_num==13 fhd=str2func('high_cond_elliptic_rot_func');   %[-100,100] F3: Shifted Rotated High Conditioned Elliptic Function
elseif func_num==14 fhd=str2func('schwefel_120_noise_func');       %[-100,100] F4: Shifted Schwefel's Problem 1.2 with Noise in Fitness
elseif func_num==15 fhd=str2func('schwefel_260');                  %[-100,100] F5: Schwefel's Problem 2.6 with Global Optimum on Bounds
elseif func_num==16 fhd=str2func('shifted_rosenbrock_func');       %[-100,100] F6: Shifted Rosenbrock's Function
elseif func_num==17 fhd=str2func('griewank_rot_func');             %[0,600]    F7: Shifted Rotated Griewank's Function without Bounds
elseif func_num==18 fhd=str2func('ackley_rot_func');               %[-32,32]   F8: Shifted Rotated Ackley's Function with Global Optimum on Bounds
elseif func_num==19 fhd=str2func('shifted_rastrigin_func');        %[-5,5]     F9: Shifted Rastrigin's Function
elseif func_num==20 fhd=str2func('rastrigin_rot_func');            %[-5,5]     F10: Shifted Rotated Rastrigin's Function
end
f=feval(fhd,x);

% Basic func 

% 1. Sphere Model
function f = sphere_func(x)
f = sum(x.^2, 2);

% 2. Rosenbrock's Function
function f = rosenbrock_func(x)
[ps,D] = size(x);
sum = 0;
for ii = 1:(D-1)
    xi = x(:,ii);
    xnext = x(:,ii+1);
    new = 100*(xnext-xi.^2).^2 + (xi-1).^2;
    sum = sum + new;
end
f = sum;

% 3. Ackley's Function
function f = ackley_func(x)
[ps,D]=size(x);
a = 20;
b = 0.2;
c = 2*pi;
sum1 = 0;
sum2 = 0;
for ii = 1:D
	xi = x(:,ii);
	sum1 = sum1 + xi.^2;
	sum2 = sum2 + cos(c*xi);
end
term1 = -a * exp(-b*sqrt(sum1/D));
term2 = -exp(sum2/D);
f = term1 + term2 + a + exp(1);


% 4. Griewank's Function
function f = griewank_func(x)
[ps,D] = size(x);
sum = 0;
prod = 1;
for ii = 1:D
	xi = x(:,ii);
	sum = sum + xi.^2/4000;
	prod = prod .* cos(xi/sqrt(ii));
end
f = sum - prod + 1;

% 5. Rastrigin's Function
function f = rastrigin_func(x)
[ps,D] = size(x);
sum = 0;
for ii = 1:D
	xi = x(:,ii);
	sum = sum + (xi.^2 - 10*cos(2*pi*xi));
end
f = 10*D + sum;

% 6. Generalized Schwefel's Problem 2.26
function f = schwefel_226(x)
[ps,D] = size(x);
sum = 0;
for i = 1:D
	xi = x(:,i);
	sum = sum + xi.*sin(sqrt(abs(xi)));
end
f = 418.9829*D - sum;

% 7. Salomon's Function
function f = salomon_func(x)
f = -cos(2*pi*sqrt(sum(x.^2,2)))+0.1*sqrt(sum(x.^2,2))+1;

% 8. Whitely's Function
function f = whitely_func(x)
[ps,D] = size(x);
sum = 0;
for i = 1:D
    xi = x(:,i);
    for j = 1:D
        xj = x(:,j);
        y = 100*(xj-xi.^2).^2+(1-xi).^2;
        sum = sum+y.^2/4000-cos(y)+1;
    end
end
f = sum;

% 9. Generalized Penalized Function 1
function f = penalized_func1(x)
[ps,D]=size(x);
a = 10;
k = 100;
m = 4;
for i = 1:ps
    for j = 1:D
        if x(i,j)>a
            u(i,j) = k*(x(i,j)-a)^m;
        elseif x(i,j)<(-a)
            u(i,j) = k*(-x(i,j)-a)^m;
        else
            u(i,j) = 0;
        end
    end
end
y = 1+0.25*(x+1);
sum = 0;
for ii = 1:(D-1)
    yi = y(:,ii);
    ynext = y(:,ii+1);
    new = (yi-1).^2.*(1+10*sin(pi*ynext).^2);
    sum = sum + new;
end
term1 = 10*sin(pi*y(:,1)).^2;
term2 = sum;
term3 = (y(:,D)-1).^2;
term4 = 0;
for jj = 1:D
    uj = u(:,jj);
    term4 = term4 + uj;
end
f = (pi/D)*(term1+term2+term3)+term4;

% 10. Generalized Penalized Function 2
function f = penalized_func2(x)
[ps,D] = size(x);
a = 5;
k = 100;
m = 4;
for i = 1:ps
    for j = 1:D
        if x(i,j)>a
            u(i,j) = k*(x(i,j)-a)^m;
        elseif x(i,j)<(-a)
            u(i,j) = k*(-x(i,j)-a)^m;
        else
            u(i,j) = 0;
        end
    end
end
sum = 0;
for ii = 1:(D-1)
    xi = x(:,ii);
    xnext = x(:,ii+1);
    new = (xi-1).^2.*(1+sin(3*pi*xnext).^2);
    sum = sum + new;
end
term1 = sin(3*pi*x(:,1)).^2;
term2 = sum;
term3 = (x(:,D)-1).^2.*(1+sin(2*pi*x(:,D)).^2);
term4 = 0;
for jj = 1:D
    uj = u(:,jj);
    term4 = term4 + uj;
end
f = 0.1*(term1+term2+term3)+term4;
% f = 0.1*(sin(3*pi*x(:,1)).^2+sum(((x(:,1:D-1)-1).^2).*(1+sin(3*pi*x(:,2:D)).^2),2)+(x(:,D)-1).^2.*(1+sin(2*pi*x(:,D)).^2))+sum(u,2);

% CEC 2005 

% 11. F1: Shifted Sphere Function
function fit = shifted_sphere_func(x)
persistent o
[ps,D] = size(x);
load sphere_func_data
if length(o)>=D
    o = o(1:D);
else
    o = -100+200*rand(1,D);
end
x = x-repmat(o,ps,1);
fit = sum(x.^2,2);

% 12. F2: Shifted Schwefel's Problem 1.2
function f = shifted_schwefel_func(x)
persistent o
[ps,D] = size(x);
load schwefel_102_data
if length(o)>=D
    o = o(1:D);
else
    o = -100+200*rand(1,D);
end
x = x-repmat(o,ps,1);
f = 0;
for i = 1:D
    f = f+sum(x(:,1:i),2).^2;
end

% 13. F3: Shifted Rotated High Conditioned Elliptic Function
function fit = high_cond_elliptic_rot_func(x)
persistent o M
[ps,D] = size(x);
load high_cond_elliptic_rot_data
if length(o)>=D
    o = o(1:D);
else
    o = -100+200*rand(1,D);
end
if D == 2
    load elliptic_M_D2,
elseif D == 10
    load elliptic_M_D10,
elseif D == 30
    load elliptic_M_D30,
elseif D == 50
    load elliptic_M_D50,
end
x = x-repmat(o,ps,1);
x = x*M;
a = 1e+6;
fit = 0;
for i = 1:D
fit = fit+a.^((i-1)/(D-1)).*x(:,i).^2;
end

% 14. F4: Shifted Schwefel's Problem 1.2 with Noise in Fitness
function f = schwefel_120_noise_func(x)
persistent o
[ps,D]=size(x);
load schwefel_102_data
if length(o)>=D
    o = o(1:D);
else
    o = -100+200*rand(1,D);
end
x = x-repmat(o,ps,1);
f = 0;
for i = 1:D
    f = f+sum(x(:,1:i),2).^2;
end
f = f.*(1+0.4.*abs(normrnd(0,1,ps,1)));

% 15. F5: Schwefel's Problem 2.6 with Global Optimum on Bounds
function f = schwefel_260(x)
persistent A B o
[ps,D] = size(x);
load schwefel_206_data
if length(o)>=D
    A = A(1:D,1:D);
    o = o(1:D);
else
    o = -100+200*rand(1,D);
    A = round(-100+2*100.*rand(D,D));
    while det(A)==0
        A = round(-100+2*100.*rand(D,D));
    end
end
o(1:ceil(D/4)) = -100;
o(max(floor(0.75*D),1):D) = 100;
B = A*o';
for i = 1:ps
    f(i,1) = max(abs(A*(x(i,:)')-B));
end

% 16. F6: Shifted Rosenbrock's Function
function f = shifted_rosenbrock_func(x)
persistent o
[ps,D] = size(x);
load rosenbrock_func_data
if length(o) >= D
    o = o(1:D);
else
    o = -90+180*rand(1,D);
end
x = x-repmat(o,ps,1)+1;
f = sum(100.*(x(:,1:D-1).^2-x(:,2:D)).^2+(x(:,1:D-1)-1).^2,2);

% 17. F7: Shifted Rotated Griewank's Function without Bounds
function f = griewank_rot_func(x)
persistent o M
[ps,D] = size(x);
load griewank_func_data
if length(o) >= D
    o = o(1:D);
else
    o=-600+0*rand(1,D);
end
if D==2,
    load griewank_M_D2,
elseif D==10,
    load griewank_M_D10,
elseif D==30,
    load griewank_M_D30,
elseif D==50,
    load griewank_M_D50,
end
o = o(1:D);
x = x-repmat(o,ps,1);
x = x*M;
f = 1;
for i=1:D
    f = f.*cos(x(:,i)./sqrt(i));
end
f = sum(x.^2,2)./4000-f+1;

% 18. F8: Shifted Rotated Ackley's Function with Global Optimum on Bounds
function f = ackley_rot_func(x)
persistent o M
[ps,D] = size(x);
load ackley_func_data
if length(o) >= D
    o = o(1:D);
else
    o = -30+60*rand(1,D);
end
o(2.*[1:floor(D/2)]-1) = -32;
if D == 2,
    load ackley_M_D2,
elseif D == 10,
    load ackley_M_D10,
elseif D == 30,
    load ackley_M_D30,
elseif D == 50,
    load ackley_M_D50,
end
x = x-repmat(o,ps,1);
x = x*M;
f = sum(x.^2,2);
f = 20-20.*exp(-0.2.*sqrt(f./D))-exp(sum(cos(2.*pi.*x),2)./D)+exp(1);

% 19. F9: Shifted Rastrigin's Function
function f = shifted_rastrigin_func(x)
persistent o
[ps,D] = size(x);
load rastrigin_func_data
if length(o)>=D
    o=o(1:D);
else
    o=-5+10*rand(1,D);
end
x = x-repmat(o,ps,1);
f = sum(x.^2-10.*cos(2.*pi.*x)+10,2);

% 20. F10: Shifted Rotated Rastrigin's Function
function f = rastrigin_rot_func(x)
persistent o M
[ps,D] = size(x);
load rastrigin_func_data
if length(o)>=D
    o = o(1:D);
else
    o = -5+10*rand(1,D);
end
if D == 2,
    load rastrigin_M_D2,
elseif D == 10,
    load rastrigin_M_D10,
elseif D == 30,
    load rastrigin_M_D30,
elseif D == 50,
    load rastrigin_M_D50,
end
x = x-repmat(o,ps,1);
x = x*M;
f = sum(x.^2-10.*cos(2.*pi.*x)+10,2);

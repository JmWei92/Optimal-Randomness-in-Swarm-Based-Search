function lu = boundary(func_num,D)
% Basic func 
if func_num==1
    lu = [-100*ones(1,D);100*ones(1,D)]; %[-100,100] 
elseif func_num==2
    lu = [-100*ones(1,D);100*ones(1,D)]; %[-100,100] 
elseif func_num==3
    lu = [-32*ones(1,D);32*ones(1,D)];   %[-32,32]
elseif func_num==4
    lu = [-600*ones(1,D);600*ones(1,D)]; %[-600,600]
elseif func_num==5
    lu = [-5*ones(1,D);5*ones(1,D)];     %[-5,5]
elseif func_num==6
    lu = [-500*ones(1,D);500*ones(1,D)]; %[-500,500]
elseif func_num==7
    lu = [-100*ones(1,D);100*ones(1,D)]; %[-100,100]
elseif func_num==8
    lu = [-100*ones(1,D);100*ones(1,D)]; %[-100,100] 
elseif func_num==9
    lu = [-50*ones(1,D);50*ones(1,D)];   %[-50,50]
elseif func_num==10
    lu = [-50*ones(1,D);50*ones(1,D)];   %[-50,50]
    % CEC2005
elseif func_num==11
    lu = [-100*ones(1,D);100*ones(1,D)]; %[-100,100] F1
elseif func_num==12
    lu = [-100*ones(1,D);100*ones(1,D)];  %[-100,100] F2
elseif func_num==13
    lu = [-100*ones(1,D);100*ones(1,D)];  %[-100,100] F3
elseif func_num==14
    lu = [-100*ones(1,D);100*ones(1,D)];  %[-100,100] F4
elseif func_num==15
    lu = [-100*ones(1,D);100*ones(1,D)];  %[-100,100] F5
elseif func_num==16
    lu = [-100*ones(1,D);100*ones(1,D)];  %[-100,100] F6
elseif func_num==17
    lu = [0*ones(1,D);600*ones(1,D)];     %[0,600] F7
elseif func_num==18
    lu = [-32*ones(1,D);32*ones(1,D)];    %[-32,32] F8
elseif func_num==19
    lu = [-5*ones(1,D);5*ones(1,D)];      %[-5,5] F9
elseif func_num==20
    lu = [-5*ones(1,D);5*ones(1,D)];      %[-5,5] F10
end

function s=simplebounds(s,Lb,Ub)
NP = size(s,1);
Lb = repmat(Lb, NP, 1);
Ub = repmat(Ub, NP, 1);
ns_tmp=s;
% Apply the lower bound
ns_tmp=s;
I=ns_tmp<Lb;
ns_tmp(I)=Lb(I);
% Apply the upper bounds 
J=ns_tmp>Ub;
ns_tmp(J)=Ub(J);
% Update this new move 
s=ns_tmp;
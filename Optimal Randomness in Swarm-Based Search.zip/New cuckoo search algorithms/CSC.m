clear all; clc;
format long;
format compact;
% CS with Cauchy distribution
min_f = [];
aver_f = [];
std_f = [];
saver_f = [];
sstd_f = [];
totalRun_iner_f = [];
problemSet = [1 : 20];
for problemIndex = 1 : length(problemSet)
    func_num = problemSet(problemIndex),
    iner_f = [];
    record = [];
    NP = 30;
    D = 30;
    maxFES = D*10000;
    totalRun = 50;
    lu = boundary(func_num,D);
    pa = 0.25;
    rand('state', sum(100 * clock));
    for time = 1 : totalRun
        outcome_f = [];
        nest = repmat(lu(1,:),NP,1)+rand(NP,D).*(repmat(lu(2,:)-lu(1,:),NP,1));
        fits = benchmark_func(nest,func_num);
        FES = 0;
        [fmin,min_i] = min(fits);
        bestnest = nest(min_i,:);
        iter = 1;
        outcome_f(iter) = fmin;
        new_nest = zeros(NP,D);
        while FES < maxFES
            iter = iter + 1;
            for i=1:NP
                %% generate Cauchy random number
                m_ca = D;
                n_ca = 1;
                mu_ca = 0.8;
                delta_ca = 4.5;
                step = randCauchy(m_ca, n_ca, mu_ca, delta_ca);
                stepsize = 0.01*step'.*(nest(i,:)-bestnest);
                new_nest(i,:) = nest(i,:)+stepsize.*randn(1,D);
            end
            if func_num ~= 17
                new_nest = simplebounds(new_nest,lu(1,:),lu(2,:));
            end
            new_fits = benchmark_func(new_nest,func_num);
            FES = FES+NP;
            iBetter = new_fits<fits;
            fits(iBetter) = new_fits(iBetter);
            nest(iBetter,:) = new_nest(iBetter,:);
            paK = rand(size(nest))>pa;
            stepsize = rand*(nest(randperm(NP),:)-nest(randperm(NP),:));
            new_nest = nest+stepsize.*paK;
            if func_num ~= 17
                new_nest = simplebounds(new_nest,lu(1,:),lu(2,:));
            end
            new_fits = benchmark_func(new_nest,func_num);
            FES = FES+NP;
            iBetter = new_fits<fits;
            fits(iBetter) = new_fits(iBetter);
            nest(iBetter,:) = new_nest(iBetter,:);
            [fmin,min_i] = min(fits);
            bestnest = nest(min_i,:);
            outcome_f(iter) = fmin;
        end
        iner_f(time,:) = outcome_f;
        record(time) = outcome_f(end); 
    end
    min_f(func_num) = min(record);  % best
    max_f(func_num) = max(record);  % worst
    med_f(func_num) = median(record);  % median
    aver_f(func_num) = mean(record);  % mean
    std_f(func_num) = std(record); % std
    totalRun_iner_f(func_num,:,:)  = iner_f;
    mean(record)
end
totalRun_CS = totalRun_iner_f;
min_f_CS = min_f;
max_f_CS = max_f;
med_f_CS = med_f;
aver_f_CS = aver_f;
std_f_CS = std_f;

% save('CS_Cauchy_30D')


